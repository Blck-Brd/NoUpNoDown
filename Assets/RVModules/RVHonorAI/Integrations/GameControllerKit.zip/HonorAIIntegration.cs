// Created by Ronis Vision. All rights reserved
// 14.04.2021.

using RVHonorAI.Combat;
using RVHonorAI.Systems;
using RVModules.RVSmartAI.Content.Scanners;
using UnityEngine;

namespace RVHonorAI
{
    /// <summary>
    /// Allows for detection and damage of GKC objects by HonorAI characters
    /// </summary>
    public class HonorAIIntegration : MonoBehaviour, ITarget, IRelationship, IScannable, IDamageable
    {
        #region Fields
        
        [SerializeField]
        private RelationshipSystem relationshipModule;
        
        [SerializeField]
        private Transform visibilityCheckTransform;

        [SerializeField]
        private Transform aimTransform;

        [SerializeField]
        private AiGroup aiGroup;

        [SerializeField]
        private bool treatNeutralCharactersAsEnemies;
        
        [Tooltip("How dangerous is this AI. Used by HonorAI, default implementation is 10% of HP * 10% of damage per second")]
        [SerializeField]
        private float danger = 20;

        [Tooltip("Radius of this AI, used by to calculate attack distance to this AI. This should be the same or close to NavMeshAgent radius of this AI")]
        [SerializeField]
        private float radius = .5f;

        #endregion

        #region Properties

        public Transform VisibilityCheckTransform => visibilityCheckTransform;

        public float Radius => radius;

        public Transform Transform => transform;

        public Transform AimTransform => aimTransform;

        public float Danger => danger;

        public AiGroup AiGroup
        {
            get => aiGroup;
            set => aiGroup = value;
        }

        public bool TreatNeutralCharactersAsEnemies => treatNeutralCharactersAsEnemies;

        public Object GetObject => this;

        #endregion

        #region Public methods

        public bool IsEnemy(IRelationship _other, bool _contraCheck = false) => relationshipModule.IsEnemy(this, _other, _contraCheck);

        public bool IsAlly(IRelationship _other) => relationshipModule.IsAlly(this, _other);


        public float ReceiveDamage(float _damage, Object _damageSource, DamageType _damageType, Vector3 hitPoint = default, Vector3 _hitForce = default,
            float forceRadius = default)
        {
            applyDamage.checkHealth(null, gameObject, _damage, transform.forward, hitPoint, null, false, false, false
                , false, false);

            return 0;
        }

        #endregion

        #region Not public methods

        private void Awake() => GetComponent<health>().eventWithAttackerOnDeath.AddListener(arg0 => Destroy(this));

        #endregion
    }
}