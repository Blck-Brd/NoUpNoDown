// Created by Ronis Vision. All rights reserved
// 14.04.2021.

using RVHonorAI.Combat;
using UnityEngine;

namespace RVHonorAI
{
    /// <summary>
    /// Allows for detection and damage of HonorAI objects by GKC
    /// </summary>
    [RequireComponent(typeof(characterFactionManager))]
    public class GKCIntegration : healthManagement
    {
        #region Fields

        private IDamageable damageable;
        private ITarget target;
        private IHitPoints hitPoints;

        #endregion

        #region Public methods

        public override GameObject getCharacterWithHealthManagement() => gameObject;

        public override GameObject getCharacterOrVehicleWithHealthManagement() => gameObject;

        public override Transform getPlaceToShootWithHealthManagement() => target.AimTransform;

        public override GameObject getPlaceToShootGameObjectWithHealthManagement() => target.AimTransform.gameObject;

        public override bool isCharacterWithHealthManagement() => true;

        public override void killCharacterWithHealthManagement() => damageable.ReceiveDamage(float.MaxValue, null, DamageType.Magic);

        public override bool checkIfDeadWithHealthManagement() => hitPoints.HitPoints <= 0;

        public override void setHealWithHealthManagement(float healAmount) => hitPoints.HitPoints += healAmount;

        public override float getMaxHealthAmountWithHealthManagement() => hitPoints.MaxHitPoints;

        public override void setDamageWithHealthManagement(float damageAmount, Vector3 fromDirection, Vector3 damagePos, GameObject attacker,
            GameObject projectile,
            bool damageConstant, bool searchClosestWeakSpot, bool ignoreShield, bool ignoreDamageInScreen, bool damageCanBeBlocked,
            bool canActivateReactionSystemTemporally)
        {
            if (damageable == null) return;
            var dmgType = DamageType.Physical;
            if (ignoreShield) dmgType = DamageType.Magic;
            damageable.ReceiveDamage(damageAmount, attacker, dmgType, damagePos);
        }

        #endregion

        #region Not public methods

        private void Start()
        {
            damageable = GetComponent<IDamageable>();
            target = GetComponent<ITarget>();
            hitPoints = GetComponent<IHitPoints>();
        }

        #endregion
    }
}